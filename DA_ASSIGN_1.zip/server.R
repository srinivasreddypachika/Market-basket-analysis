library(shiny) 
#data(data1) 
data1 <- read.csv("employee_attrition.csv")

shinyServer(
  
  
  function(input, output) {
    
    output$text1 <- renderText({ 
      colm = as.numeric(input$var)
      paste("Data set variable/column name is", names(data1[colm]))
      
    })
    
    output$text2 <- renderText({ 
      paste("Color of histogram is", input$radio)
    })
    
    output$text3 <- renderText({ 
      paste("Number of histogram BINs is", input$bin)
    })
    
    output$myhist <- renderPlot(
      
      {
        colm = as.numeric(input$var)
        hist(data1[,colm], col =input$colour, xlim = c(0, max(data1[,colm])), main = "Histogram of employee attrition dataset", breaks = seq(0, max(data1[,colm]),l=input$bin+1), xlab = names(data1[colm]))}
      
    )    
  }
)

